DATABASE DETAILS
The SQL database used here is MySQL. The database consists of the following tables:

1) Authors: It consists of two columns “Author_id” and “Name” , here “Author_id” is the primary key. Column “Author_id” is of type integer and “Name” is of 
type varchar.
2) Book: It consists of two columns “Isbn” and “Title”, here Isbn is the primary key. “Isbn” is of type bigint and “Title” is of type varchar.
3) Book_Authors: It consists of two columns “Author_id” and “Isbn”, here both columns combined form a primary key. “Author_id” is of type integer 
and “Isbn” is of type bigint “Author_id” has a foreign key constraint and it refers to “Author_id” of Authors. “Isbn” has a foreign key constraint and it 
refers to “Isbn” of Book table.
4) Book_Loans: It consists of six columns, “Loan_id”, “Isbn”, “Card_id”, “Date_out”, “Due_date”, “Date_in”, here “Loan_id” column is the primary key. “Isbn” 
and “Card_id” have foreign key constraints and they refer to “Isbn” of Book and “Card_id” of Borrower respectively.
5) Borrower: It consists of six columns, “Card_id”, “Ssn”, “Bname”, “Address”, “Phone”, here “Card_id” column is the primary key and “Ssn” column has a 
unique constraint on it.
6) Fines: It consists of 3 columns “Loan_id”, “Fine_amt”, “Paid”, here “Loan_id” is the primary key. “Loan_id” also has a foreign key constraint and it
 refers to “Loan_id” of Book_Loans.

GUI DETAILS
The GUI is implemented using Java programming language. Here, Jswing which is the standard GUI library for Java is used and we query the database using
 mySQL

1) The user can search for a book, after which he is given the option to issue the book to the borrower provided the borrower hasn’t already borrowed 3 books 
and the book is available.
2) The user can add details of new borrowers.
3) When the user clicks the refresh button, the fine amounts of all the checked out books is updated.
4) The user can check-in a book by searching for a book and then clicking the check-in button, before the book check-in the user will be asked to confirm 
weather the borrower has cleared the fine amount or not related to the book.

DEPENDENCIES
1) You need to install Java Netbeans, JDK, JDBC connector.
2) Need to have MySql, MySql Work bench
3) Need to connect JDBC in Java
4) Upload the data from the tables of csv files into the Data Base
5) Import the Files as a project to Net Beans
6) Run the Program
7) There is a jar file in the folder of dist in library_management_system we can run it to see the overall performance